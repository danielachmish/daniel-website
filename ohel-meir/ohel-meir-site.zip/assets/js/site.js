/* site.js — בלי ספריות. כל מה שכאן הוא שיפור: הדף עובד וקריא גם בלי JS. */
(function () {
  'use strict';
  var doc = document.documentElement;
  doc.classList.add('js');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- כניסה מדורגת של אלמנטים ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('is-in'); });
  }

  /* ---------- כפתור דביק בטלפון: מופיע אחרי שכפתור ה-Hero יצא מהמסך, ונעלם כשמגיעים לטופס (וגם אחריו) ---------- */
  var sticky = document.querySelector('.sticky-cta');
  var heroCta = document.querySelector('[data-hero-cta]');
  var formSection = document.getElementById('contact-form-section') || document.querySelector('.site-footer');
  if (sticky && heroCta && formSection) {
    var ticking = false;
    var update = function () {
      ticking = false;
      var vh = window.innerHeight;
      var heroGone = heroCta.getBoundingClientRect().bottom < 0;
      var beforeForm = formSection.getBoundingClientRect().top > vh * 0.85;
      var show = heroGone && beforeForm;
      if (sticky.classList.contains('is-visible') === show) return;
      sticky.classList.toggle('is-visible', show);
      sticky.setAttribute('aria-hidden', show ? 'false' : 'true');
      sticky.querySelectorAll('a,button').forEach(function (el) { el.tabIndex = show ? 0 : -1; });
    };
    var onScroll = function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    update();
  }


  /* ---------- תפריט בטלפון ---------- */
  var menuBtn = document.querySelector('.menu-btn');
  var nav = document.getElementById('site-nav');
  if (menuBtn && nav) {
    var setMenu = function (open) {
      nav.classList.toggle('is-open', open);
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      menuBtn.querySelector('span').textContent = open ? 'סגירה' : 'תפריט';
    };
    menuBtn.addEventListener('click', function () { setMenu(!nav.classList.contains('is-open')); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && nav.classList.contains('is-open')) { setMenu(false); menuBtn.focus(); } });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
  }


  /* ---------- "הצגת ידיעות נוספות" (12 בכל פעם) ---------- */
  var moreBtn = document.querySelector('[data-more]');
  var newsCards = Array.prototype.slice.call(document.querySelectorAll('.news-grid [data-cat]'));
  var PAGE = 12, shownCount = PAGE, activeCat = 'all';
  function paint() {
    var match = newsCards.filter(function (c) { return activeCat === 'all' || c.dataset.cat === activeCat; });
    newsCards.forEach(function (c) { c.hidden = true; });
    match.forEach(function (c, i) { c.hidden = i >= shownCount; });
    if (moreBtn) moreBtn.hidden = match.length <= shownCount;
    return match.length;
  }
  if (moreBtn && newsCards.length) {
    paint();
    moreBtn.addEventListener('click', function () {
      var first = newsCards.filter(function (c) { return c.hidden && (activeCat === 'all' || c.dataset.cat === activeCat); })[0];
      shownCount += PAGE; paint();
      if (first) { var a = first.querySelector('a'); if (a) a.focus(); }
    });
  }

  /* ---------- בחירת נושא בטופס לפי הקישור (למשל רישום לכיתה א׳) ---------- */
  try {
    if (new URLSearchParams(location.search).get('subject') === 'registration') {
      var opt = document.getElementById('opt-registration'); if (opt) opt.selected = true;
    }
  } catch (e) {}

  /* ---------- סינון ידיעות לפי נושא ---------- */
  var filterBar = document.querySelector('[data-filters]');
  if (filterBar) {
    var cards = document.querySelectorAll('[data-cat]');
    var empty = document.querySelector('[data-empty]');
    filterBar.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      filterBar.querySelectorAll('button').forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
      activeCat = b.dataset.filter; shownCount = PAGE;
      var shown = paint();
      if (empty) empty.hidden = shown > 0;
      var live = document.querySelector('[data-filter-live]');
      if (live) live.textContent = 'מוצגות ' + shown + ' ידיעות';
    });
  }

  /* ---------- שנה בפוטר ---------- */
  document.querySelectorAll('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- טופס לידים ---------- */
  var form = document.querySelector('form[data-lead-form]');
  if (!form) return;

  // מקור ההגעה (UTM) נשמר בשדות נסתרים, כדי לדעת איזה קמפיין הביא את הליד
  try {
    var params = new URLSearchParams(location.search);
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'gclid', 'fbclid'].forEach(function (k) {
      var f = form.querySelector('input[name="' + k + '"]');
      if (f && params.get(k)) f.value = params.get(k).slice(0, 120);
    });
  } catch (e) { /* אין תמיכה: לא קריטי */ }
  var started = form.querySelector('input[name="_started"]');
  if (started) started.value = String(Date.now());

  var digits = function (s) { return (s || '').replace(/\D+/g, ''); };
  var rules = {
    required: function (v, el) { return el.type === 'checkbox' ? el.checked : v.trim().length > 0; },
    name: function (v) { return v.trim().length >= 2; },
    phoneIL: function (v) { var d = digits(v).replace(/^972/, '0'); return /^0(5\d|7\d|[2-489])\d{7}$/.test(d); },
    email: function (v) { return v === '' || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()); },
    bizId: function (v) { var d = digits(v); return d.length >= 8 && d.length <= 9; }
  };

  // כל שדה עם data-validate מצביע (aria-describedby) על אלמנט שגיאה שה-id שלו נגמר ב-"-err"
  var errorOf = function (el) {
    var ids = (el.getAttribute('aria-describedby') || '').split(' ');
    for (var i = 0; i < ids.length; i++) if (/-err$/.test(ids[i])) return document.getElementById(ids[i]);
    return null;
  };

  function validate(el) {
    var v = el.type === 'checkbox' ? '' : el.value;
    var msg = '';
    if (el.required && !rules.required(v, el)) msg = el.dataset.msgRequired || 'שדה חובה';
    else if (v && el.dataset.rule && rules[el.dataset.rule] && !rules[el.dataset.rule](v)) msg = el.dataset.msgInvalid || 'הערך לא תקין';
    var err = errorOf(el);
    if (err) err.textContent = msg;
    el.setAttribute('aria-invalid', msg ? 'true' : 'false');
    return !msg;
  }

  var inputs = Array.prototype.slice.call(form.querySelectorAll('[data-validate]'));
  inputs.forEach(function (el) {
    el.addEventListener('blur', function () { if (el.value || el.dataset.touched) validate(el); el.dataset.touched = '1'; });
    el.addEventListener('input', function () { if (el.getAttribute('aria-invalid') === 'true') validate(el); });
    el.addEventListener('change', function () { if (el.type === 'checkbox' || el.tagName === 'SELECT') validate(el); });
  });

  var status = form.querySelector('.form-status');
  var btn = form.querySelector('button[type="submit"]');
  var btnLabel = btn ? btn.innerHTML : '';

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    status.textContent = ''; status.className = 'form-status';
    var bad = inputs.filter(function (el) { return !validate(el); });
    if (bad.length) {
      status.classList.add('form-status--error');
      status.textContent = bad.length === 1 ? 'יש שדה אחד שצריך לתקן.' : 'יש ' + bad.length + ' שדות שצריך לתקן.';
      bad[0].focus();
      return;
    }
    var data = Object.fromEntries(new FormData(form).entries());
    // בוט מילא את שדה המלכודת: מציגים הצלחה ולא שולחים כלום
    if (data.company_website) { return success(); }
    if (data.phone) data.phone = digits(data.phone).replace(/^972/, '0');

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner" aria-hidden="true"></span> שולחים…';

    // מצב הדגמה (data-demo="true"): בלי שרת. להסיר לפני עלייה לאוויר! qa_web.mjs מזהיר על זה.
    if (form.dataset.demo === 'true') { setTimeout(success, 700); return; }

    var ctrl = 'AbortController' in window ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 15000);
    fetch(form.action, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(data),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (r) {
      clearTimeout(timer);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      success();
      if (window.dataLayer) window.dataLayer.push({ event: 'generate_lead', form: form.id });
    }).catch(function () {
      clearTimeout(timer);
      btn.disabled = false; btn.innerHTML = btnLabel;
      status.classList.add('form-status--error');
      status.textContent = form.dataset.msgFail || 'השליחה לא הצליחה. בדקו את החיבור ונסו שוב.';
      if (form.dataset.fallbackHref) { // דרך חלופית: טלפון / וואטסאפ
        var alt = document.createElement('a');
        alt.href = form.dataset.fallbackHref; alt.className = 'form-status__alt';
        alt.textContent = form.dataset.fallbackLabel || 'או דברו איתנו ישירות';
        if (form.dataset.fallbackNumber) { var bd = document.createElement('bdi'); bd.textContent = form.dataset.fallbackNumber; alt.appendChild(document.createTextNode('\u00a0')); alt.appendChild(bd); }
        status.appendChild(document.createTextNode(' ')); status.appendChild(alt);
      }
      status.focus();
    });
  });

  function success() {
    var tpl = document.getElementById('form-success');
    var card = form.closest('.form-card');
    if (tpl && card) {
      card.innerHTML = tpl.innerHTML;
      var h = card.querySelector('h3');
      if (h) { h.tabIndex = -1; h.focus(); }
    }
  }
})();
